# This is stub file.
# You should copy it into 'settings_prod_private.py' and fill with real data on the production server.

SECRET_KEY = '1@4i==7-0$*jmu_5-8o1x+i82vera$25&-x!qu7&g!u89z0a(l'

ALLOWED_HOSTS = ['irunner2.bsu']

WORKER_TOKEN = 'abacaba'

EMAIL_HOST_PASSWORD = 'abacaba'
