Applications
============

common
------
This application contains generic utility code.
It should not depend on other applications.

users
-----
Managing users and administrator groups.

cauth
-----
Logging in and logging out, two-factor authentication.
