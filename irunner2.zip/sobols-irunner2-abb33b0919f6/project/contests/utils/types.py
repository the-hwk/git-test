class SolutionKind(object):
    PENDING = 1
    ACCEPTED = 2
    REJECTED = 3
