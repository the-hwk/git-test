This directory contains Internet Information Services (IIS) configs.
Put them into `C:\inetpub`.
