Build the image:
```
$ docker build . -t irunner-worker
```

Explore the image:
```
$ docker run -i -t irunner-worker
```
